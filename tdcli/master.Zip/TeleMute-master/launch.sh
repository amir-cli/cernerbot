#!/bin/bash

./tg -s bot.lua


