# [TeleMute](https://github.com/MutePuker/TeleMute)
*TG-CLI based broadcasting bot!*
# Install
```
cd $HOME
git clone https://github.com/MutePuker/TeleMute.git
cd TeleMute
chmod +x install.sh
chmod +x launch.sh
chmod +x tg
./install.sh
./launch.sh
# Enter a phone number & confirmation code.
```
Create a bot!
# Help And More...
send ```Your PM``` to @MutePukerBot in telegram
# Developers
* [@MutePuker](https://telegram.me/MutePuker) - Shervin
* [@amirhossein_h_h_h](https://telegram.me/amirhossein_h_h_h) - amirhosein

# Commands

### All Commands

>[!/]createsuper [group name]
>
>>[!/]createsuperMute
>>>will create a SuperGroup
>>>
>>>_Only works in realms for admins but, sudo users can use it everywhere_

>[!/]ping
>>Test Online
>
>[!/]id
>>Send Your ID


>[!/]pin
>>Pinned MSG To GRoup
>
>[!/]unpin
>>UnPinned MSG To Group

>[!/]lock links
>>Lock Links MSG

>[!/]unlock links
>>UNLock Links MSG
>
>[!/]Mute all
>>Mute All MSG To Group


> [!/]unmute all 
>>>UnMute All MSG To Group

> [!/]settings
>>>Send Settings MSG

> [!/]fwd
>>>Forward a MSG

> [!/]username [username]
>>>SetUserName For Group

> [!/]echo [MSG}
>>>Echo a MSG

> [!/]setname [NAME]
>>>Set Name For Group

> [!/]edit [TEXT]
>>>Editted MSG

> [!/]view [reply]
>>>View a MSG

> [!/]unmute all 
>>>UnMute All MSG To Group

<b>Powered By MuteTeam</b>
